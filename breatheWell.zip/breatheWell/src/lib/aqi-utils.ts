import type { LucideIcon } from 'lucide-react';
import { Leaf, CloudSun, Users, ShieldAlert, Frown, Biohazard, Smile, CloudFog, ShieldQuestion } from 'lucide-react';

export interface AQIDescriptor {
  level: string;
  colorClass: string; 
  bgColorClass: string;
  Icon: LucideIcon;
  iconColorClass: string;
}

// Standard AQI colors. These specific text color classes will be used.
// They are not theme dependent to maintain universal understanding of AQI colors.
const aqiColors = {
  good: 'text-green-400',
  moderate: 'text-yellow-400',
  usg: 'text-orange-400',
  unhealthy: 'text-red-400',
  veryUnhealthy: 'text-purple-400',
  hazardous: 'text-red-700', // A darker, more severe red
  unknown: 'text-gray-400',
};

const aqiBgColors = {
  good: 'bg-green-500/30',
  moderate: 'bg-yellow-500/30',
  usg: 'bg-orange-500/30',
  unhealthy: 'bg-red-500/30',
  veryUnhealthy: 'bg-purple-500/30',
  hazardous: 'bg-red-700/30',
  unknown: 'bg-gray-500/30',
}

export function getAQIDescriptor(aqi: number | undefined | null): AQIDescriptor {
  if (aqi === undefined || aqi === null) {
     return { level: 'Unknown', colorClass: aqiColors.unknown, bgColorClass: aqiBgColors.unknown, Icon: ShieldQuestion, iconColorClass: aqiColors.unknown };
  }
  if (aqi <= 50) {
    return { level: 'Good', colorClass: aqiColors.good, bgColorClass: aqiBgColors.good, Icon: Smile, iconColorClass: aqiColors.good };
  }
  if (aqi <= 100) {
    return { level: 'Moderate', colorClass: aqiColors.moderate, bgColorClass: aqiBgColors.moderate, Icon: Leaf, iconColorClass: aqiColors.moderate };
  }
  if (aqi <= 150) {
    return { level: 'Unhealthy for Sensitive Groups', colorClass: aqiColors.usg, bgColorClass: aqiBgColors.usg, Icon: Users, iconColorClass: aqiColors.usg };
  }
  if (aqi <= 200) {
    return { level: 'Unhealthy', colorClass: aqiColors.unhealthy, bgColorClass: aqiBgColors.unhealthy, Icon: CloudFog, iconColorClass: aqiColors.unhealthy };
  }
  if (aqi <= 300) {
    return { level: 'Very Unhealthy', colorClass: aqiColors.veryUnhealthy, bgColorClass: aqiBgColors.veryUnhealthy, Icon: ShieldAlert, iconColorClass: aqiColors.veryUnhealthy };
  }
  return { level: 'Hazardous', colorClass: aqiColors.hazardous, bgColorClass: aqiBgColors.hazardous, Icon: Biohazard, iconColorClass: aqiColors.hazardous };
}
