'use server';

/**
 * @fileOverview Air pollution precaution suggestion AI agent.
 *
 * - suggestPrecautions - A function that suggests precautions based on air quality.
 * - SuggestPrecautionsInput - The input type for the suggestPrecautions function.
 * - SuggestPrecautionsOutput - The return type for the suggestPrecautions function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SuggestPrecautionsInputSchema = z.object({
  city: z.string().describe('The city for which precautions are needed.'),
  aqi: z.number().describe('The predicted Air Quality Index (AQI) value.'),
});
export type SuggestPrecautionsInput = z.infer<typeof SuggestPrecautionsInputSchema>;

const SuggestPrecautionsOutputSchema = z.object({
  precautions: z
    .array(z.string())
    .describe('A list of personalized precautions to take based on the predicted AQI.'),
});
export type SuggestPrecautionsOutput = z.infer<typeof SuggestPrecautionsOutputSchema>;

export async function suggestPrecautions(input: SuggestPrecautionsInput): Promise<SuggestPrecautionsOutput> {
  return suggestPrecautionsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'suggestPrecautionsPrompt',
  input: {schema: SuggestPrecautionsInputSchema},
  output: {schema: SuggestPrecautionsOutputSchema},
  prompt: `You are an AI assistant specializing in providing personalized health precautions based on air quality for Indian cities.

  Based on the predicted AQI for {{city}}, suggest a list of precautions that a person can take to protect their health.

  AQI: {{aqi}}
  City: {{city}}

  Provide specific and actionable advice.
`,
});

const suggestPrecautionsFlow = ai.defineFlow(
  {
    name: 'suggestPrecautionsFlow',
    inputSchema: SuggestPrecautionsInputSchema,
    outputSchema: SuggestPrecautionsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
