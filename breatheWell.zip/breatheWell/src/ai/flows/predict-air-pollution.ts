// src/ai/flows/predict-air-pollution.ts
'use server';
/**
 * @fileOverview Predicts the air pollution level for a given city in India for the next day and suggests precautions.
 *
 * - predictAirPollution - A function that predicts air pollution and suggests precautions.
 * - PredictAirPollutionInput - The input type for the predictAirPollution function.
 * - PredictAirPollutionOutput - The return type for the predictAirPollution function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const PredictAirPollutionInputSchema = z.object({
  city: z.string().describe('The name of the Indian city or town to predict air pollution for.'),
});
export type PredictAirPollutionInput = z.infer<typeof PredictAirPollutionInputSchema>;

const PredictAirPollutionOutputSchema = z.object({
  aqi: z.number().describe('The predicted Air Quality Index (AQI) value for the next day.'),
  pollutionLevel: z
    .string()
    .describe(
      'A color-coded indicator representing the pollution level (e.g., green for good, red for hazardous).'
    ),
  precautions: z
    .string()
    .describe('Suggested precautions based on the predicted air quality for the next day.'),
});
export type PredictAirPollutionOutput = z.infer<typeof PredictAirPollutionOutputSchema>;

export async function predictAirPollution(input: PredictAirPollutionInput): Promise<PredictAirPollutionOutput> {
  return predictAirPollutionFlow(input);
}

const prompt = ai.definePrompt({
  name: 'predictAirPollutionPrompt',
  input: {schema: PredictAirPollutionInputSchema},
  output: {schema: PredictAirPollutionOutputSchema},
  prompt: `You are an AI assistant specializing in predicting air pollution levels in Indian cities and suggesting precautions.
  Given the city name, predict the Air Quality Index (AQI) for the next day. Also, provide a color-coded pollution level indicator and suggest appropriate precautions.

  City: {{{city}}}

  Respond in JSON format.
  `,
});

const predictAirPollutionFlow = ai.defineFlow(
  {
    name: 'predictAirPollutionFlow',
    inputSchema: PredictAirPollutionInputSchema,
    outputSchema: PredictAirPollutionOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);

