import { config } from 'dotenv';
config();

import '@/ai/flows/suggest-precautions.ts';
import '@/ai/flows/predict-air-pollution.ts';