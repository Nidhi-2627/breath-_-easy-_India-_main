"use client";

import { useState } from 'react';
import type { FormEvent } from 'react';
import { predictAirPollution, type PredictAirPollutionOutput } from '@/ai/flows/predict-air-pollution';

// Components
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import HeroSection from '@/components/sections/HeroSection';
import SearchSection from '@/components/sections/SearchSection';
import ResultsSection from '@/components/sections/ResultsSection';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Loader2, AlertTriangle } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";


export default function HomePage() {
  const [city, setCity] = useState('');
  const [prediction, setPrediction] = useState<PredictAirPollutionOutput | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!city.trim()) {
      setError('Please enter a city name.');
      toast({
        title: "Input Error",
        description: "City name cannot be empty.",
        variant: "destructive",
      });
      return;
    }
    setIsLoading(true);
    setError(null);
    setPrediction(null); // Clear previous prediction
    try {
      const result = await predictAirPollution({ city });
      if (result && typeof result.aqi === 'number') {
        setPrediction(result);
        toast({
          title: "Prediction Successful",
          description: `Air quality for ${city} predicted.`,
        });
      } else {
        throw new Error("Received invalid prediction data from AI.");
      }
    } catch (e) {
      console.error(e);
      const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred.';
      setError(`Failed to fetch air pollution data: ${errorMessage}. Please try again or check the city name.`);
      toast({
        title: "Prediction Failed",
        description: `Could not get data for ${city}. Please check the spelling or try another city.`,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8">
        <SearchSection
          city={city}
          setCity={setCity}
          onSubmit={handleSubmit}
          isLoading={isLoading}
        />
        <HeroSection />
        
        {isLoading && (
          <div className="flex flex-col justify-center items-center my-12 p-8 bg-card rounded-lg shadow-md">
            <Loader2 className="h-16 w-16 animate-spin text-primary" />
            <p className="ml-4 mt-4 text-xl font-semibold font-body text-foreground/90">
              Predicting air quality for {city}...
            </p>
            <p className="text-sm text-muted-foreground font-body mt-1">This may take a moment.</p>
          </div>
        )}

        {error && !isLoading && (
          <Alert variant="destructive" className="my-8 max-w-xl mx-auto shadow-lg">
            <AlertTriangle className="h-5 w-5" />
            <AlertTitle className="font-headline">Prediction Error</AlertTitle>
            <AlertDescription className="font-body">{error}</AlertDescription>
          </Alert>
        )}

        {prediction && !isLoading && (
          <ResultsSection prediction={prediction} />
        )}
      </main>
      <Footer />
    </div>
  );
}
