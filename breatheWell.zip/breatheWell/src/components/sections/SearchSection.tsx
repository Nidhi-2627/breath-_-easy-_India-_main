import type { FormEvent, Dispatch, SetStateAction } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Search } from 'lucide-react';

interface SearchSectionProps {
  city: string;
  setCity: Dispatch<SetStateAction<string>>;
  onSubmit: (event: FormEvent<HTMLFormElement>) => void;
  isLoading: boolean;
}

export default function SearchSection({ city, setCity, onSubmit, isLoading }: SearchSectionProps) {
  return (
    <section className="my-8 md:my-12">
      <Card className="max-w-xl mx-auto shadow-lg">
        <CardHeader>
          <CardTitle className="font-headline text-2xl text-center text-primary">
            Check Air Quality
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={onSubmit} className="space-y-4">
            <div>
              <label htmlFor="city-search" className="sr-only">Search for a city in India</label>
              <Input
                id="city-search"
                type="text"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="Enter an Indian city or town (e.g., Delhi, Mumbai)"
                className="w-full font-body text-base"
                aria-label="City name for air quality prediction"
                disabled={isLoading}
              />
            </div>
            <Button 
              type="submit" 
              className="w-full font-body text-lg" 
              disabled={isLoading}
              variant="default"
              size="lg"
            >
              <Search className="mr-2 h-5 w-5" />
              {isLoading ? 'Predicting...' : 'Get Prediction'}
            </Button>
          </form>
        </CardContent>
      </Card>
    </section>
  );
}
