import type { PredictAirPollutionOutput } from '@/ai/flows/predict-air-pollution';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { getAQIDescriptor, type AQIDescriptor } from '@/lib/aqi-utils';
import { Thermometer, AlertOctagon, ListChecks } from 'lucide-react';

interface ResultsSectionProps {
  prediction: PredictAirPollutionOutput;
}

export default function ResultsSection({ prediction }: ResultsSectionProps) {
  const aqiDescriptor: AQIDescriptor = getAQIDescriptor(prediction.aqi);

  return (
    <section className="my-8 md:my-12">
      <div className="grid md:grid-cols-3 gap-6">
        
        <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-lg font-headline font-medium text-primary">
              Predicted AQI
            </CardTitle>
            <Thermometer className="h-6 w-6 text-accent" />
          </CardHeader>
          <CardContent>
            <div className={`text-5xl font-bold font-headline ${aqiDescriptor.colorClass}`}>
              {prediction.aqi ?? 'N/A'}
            </div>
            <p className={`text-sm font-body mt-1 ${aqiDescriptor.colorClass}`}>
              {aqiDescriptor.level}
            </p>
          </CardContent>
        </Card>

        <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-lg font-headline font-medium text-primary">
              Pollution Level
            </CardTitle>
             <aqiDescriptor.Icon className={`h-6 w-6 ${aqiDescriptor.iconColorClass}`} />
          </CardHeader>
          <CardContent>
            <div 
              className={`px-4 py-3 rounded-md ${aqiDescriptor.bgColorClass}`}
            >
              <div className="flex items-center space-x-3">
                 <aqiDescriptor.Icon className={`h-10 w-10 ${aqiDescriptor.iconColorClass}`} />
                <div>
                  <p className={`text-2xl font-bold font-headline ${aqiDescriptor.colorClass}`}>
                    {aqiDescriptor.level}
                  </p>
                  {prediction.pollutionLevel && (
                     <p className="text-xs text-muted-foreground font-body">
                       AI says: {prediction.pollutionLevel}
                     </p>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="md:col-span-3 lg:col-span-1 shadow-lg hover:shadow-xl transition-shadow duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-lg font-headline font-medium text-primary">
              Health Precautions
            </CardTitle>
            <ListChecks className="h-6 w-6 text-accent" />
          </CardHeader>
          <CardContent>
            <p className="font-body text-sm text-foreground/90 leading-relaxed whitespace-pre-line">
              {prediction.precautions || "No specific precautions provided by AI. General advice: " + (aqiDescriptor.level === "Good" ? "Enjoy your day!" : "Follow standard health guidelines for current air quality.")}
            </p>
          </CardContent>
        </Card>

      </div>
    </section>
  );
}
