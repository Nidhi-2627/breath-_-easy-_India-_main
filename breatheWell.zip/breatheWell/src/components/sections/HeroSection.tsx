import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function HeroSection() {
  return (
    <section className="my-8 md:my-12 text-center">
      <Card className="max-w-2xl mx-auto bg-card/50 border-2 border-primary/30 shadow-xl">
        <CardHeader>
          <CardTitle className="font-headline text-3xl md:text-4xl font-bold text-primary">
            Welcome to BreatheWell
          </CardTitle>
          <CardDescription className="font-body text-md md:text-lg text-foreground/90 mt-2">
            Your guide to understanding and navigating air quality in India.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="font-body text-sm md:text-base text-foreground/80 leading-relaxed">
            BreatheWell helps you predict the next day's air pollution levels for cities and towns across India. 
            Get timely Air Quality Index (AQI) predictions and personalized precautionary suggestions to safeguard your health. 
            Simply enter a city name above to get started.
          </p>
        </CardContent>
      </Card>
    </section>
  );
}
