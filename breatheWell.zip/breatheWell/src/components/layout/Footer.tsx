export default function Footer() {
  return (
    <footer className="py-6 bg-card border-t border-border mt-auto">
      <div className="container mx-auto px-4 text-center">
        <p className="text-sm text-muted-foreground font-body">
          Disclaimer: Predictions are AI-generated and may not always be accurate. Air quality data is for informational purposes only. Please consult official government sources for critical health decisions.
        </p>
        <p className="text-xs text-muted-foreground/70 font-body mt-2">
          &copy; {new Date().getFullYear()} BreatheWell. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
