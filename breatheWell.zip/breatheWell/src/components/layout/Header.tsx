import Link from 'next/link';
import { TreePine } from 'lucide-react';

export default function Header() {
  return (
    <header className="py-6 bg-background/80 backdrop-blur-md shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <Link href="/" className="flex items-center space-x-2 text-3xl font-headline font-bold text-primary hover:text-primary/90 transition-colors">
          <TreePine className="h-8 w-8" />
          <span>BreatheWell</span>
        </Link>
      </div>
    </header>
  );
}
